modulejs.define('core/langs', ['config', '_'], function (config, _) {

    return _.extend({}, config.langs);
});
